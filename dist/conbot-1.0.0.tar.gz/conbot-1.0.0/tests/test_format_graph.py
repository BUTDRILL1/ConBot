import pytest
from conbot.format_graph import get_category_for_ext, get_valid_targets, get_valid_target_categories

def test_get_category_for_ext():
    assert get_category_for_ext(".md") == "Document"
    assert get_category_for_ext(".MD") == "Document"
    assert get_category_for_ext(".mp4") == "Video"
    assert get_category_for_ext(".unknown") is None

def test_get_valid_targets():
    md_targets = get_valid_targets(".md")
    assert ".pdf" in md_targets
    assert ".docx" in md_targets
    assert md_targets[".docx"].engine == "pandoc"
    
    docx_targets = get_valid_targets(".docx")
    assert ".epub" in docx_targets
    assert docx_targets[".epub"].warning is not None

def test_get_valid_target_categories():
    cats = get_valid_target_categories(".md")
    assert "Document" in cats
    assert "Video" not in cats
