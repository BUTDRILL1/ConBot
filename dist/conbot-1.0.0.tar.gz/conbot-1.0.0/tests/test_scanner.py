import pytest
from pathlib import Path
from conbot.scanner import get_compound_extension, scan_directory, get_files_by_extension

def test_get_compound_extension():
    assert get_compound_extension(Path("file.md")) == ".md"
    assert get_compound_extension(Path("archive.tar.gz")) == ".tar.gz"
    assert get_compound_extension(Path("NO_EXTENSION")) == ""
    assert get_compound_extension(Path("file.MD")) == ".md"

def test_get_files_by_extension():
    files = [Path("test1.md"), Path("test2.MD"), Path("archive.tar.gz"), Path("image.png")]
    grouped = get_files_by_extension(files)
    
    assert ".md" in grouped
    assert len(grouped[".md"]) == 2
    assert ".tar.gz" in grouped
    assert ".png" in grouped
    assert "MD" not in grouped  # Should be normalized
